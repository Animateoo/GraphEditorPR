/*
    GraphEditorPR Host Script - Premiere Pro Version
    --------------------------------------------------------------------------
    Reforzado para Premiere Pro 2026 - Soporte total de Máscaras y Curvas
    -------------------------------------------------------------------------
*/

var _GRAPHEDITORPR = {};

(function () {
    'use strict';

    var BAKING_STEPS = 20; // Aumentado para mayor fluidez en máscaras
    try { if (app && app.enableQE) app.enableQE(); } catch (eQE) { }

    function withUndoGroup(name, fn) {
        try {
            if (typeof qe !== 'undefined' && qe && qe.project && qe.project.beginUndoGroup) {
                qe.project.beginUndoGroup(name);
            }
        } catch (e1) { }
        try {
            return fn();
        } finally {
            try {
                if (typeof qe !== 'undefined' && qe && qe.project && qe.project.endUndoGroup) {
                    qe.project.endUndoGroup();
                }
            } catch (e2) { }
        }
    }

    // Undo propio (atajo dentro del panel). CEP no puede engancharse a Ctrl+Z global de Premiere como UXP.
    var _UNDO_STACK = [];
    var _REDO_STACK = [];
    var _UNDO_UID = 1;

    function _getPropUid(prop) {
        try {
            if (!prop.__gepr_uid) prop.__gepr_uid = (_UNDO_UID++);
            return prop.__gepr_uid;
        } catch (e) {
            return null;
        }
    }

    // --- MOTOR DE INTERPOLACIÓN BEZIER ---
    function getBezierPoint(t, p0, p1, p2, p3) {
        var u = 1 - t;
        return (u * u * u * p0) + (3 * u * u * t * p1) + (3 * u * t * t * p2) + (t * t * t * p3);
    }

    function solveBezierT(x, p1x, p2x) {
        var t = x;
        for (var i = 0; i < 8; i++) {
            var currentX = getBezierPoint(t, 0, p1x, p2x, 1) - x;
            var dx = 3 * Math.pow(1 - t, 2) * p1x + 6 * (1 - t) * t * (p2x - p1x) + 3 * Math.pow(t, 2) * (1 - p2x);
            if (Math.abs(dx) < 0.0001) break;
            t -= currentX / dx;
            t = Math.max(0, Math.min(1, t));
        }
        return t;
    }

    // --- INTERPOLACIÓN DE VALORES COMPLEJOS (SOPORTE MÁSCARAS) ---
    function interpolateValue(v1, v2, t) {
        if (v1 === null || v1 === undefined) return v2;
        if (v2 === null || v2 === undefined) return v1;

        // Caso 1: Números simples
        if (typeof v1 === 'number') {
            return v1 + (v2 - v1) * t;
        }

        // Caso 2: Objetos con X/Y (Puntos de PPro)
        if (v1.hasOwnProperty('x') && v1.hasOwnProperty('y')) {
            return {
                x: v1.x + (v2.x - v1.x) * t,
                y: v1.y + (v2.y - v1.y) * t
            };
        }

        // Caso 3: Propiedades de Máscara (Shape / Path)
        if (v1.hasOwnProperty('vertices')) {
            var res = {
                vertices: [],
                inTangents: [],
                outTangents: [],
                closed: v1.closed
            };
            var len = v1.vertices.length;
            for (var i = 0; i < len; i++) {
                var pt1 = v1.vertices[i];
                var pt2 = (v2.vertices && v2.vertices[i]) ? v2.vertices[i] : pt1;
                res.vertices.push([pt1[0] + (pt2[0] - pt1[0]) * t, pt1[1] + (pt2[1] - pt1[1]) * t]);

                var it1 = v1.inTangents[i];
                var it2 = (v2.inTangents && v2.inTangents[i]) ? v2.inTangents[i] : it1;
                res.inTangents.push([it1[0] + (it2[0] - it1[0]) * t, it1[1] + (it2[1] - it1[1]) * t]);

                var ot1 = v1.outTangents[i];
                var ot2 = (v2.outTangents && v2.outTangents[i]) ? v2.outTangents[i] : ot1;
                res.outTangents.push([ot1[0] + (ot2[0] - ot1[0]) * t, ot1[1] + (ot2[1] - ot1[1]) * t]);
            }
            return res;
        }

        // Caso 4: Arrays (Colores, Escala 3D)
        if (v1.length !== undefined) {
            var arr = [];
            for (var d = 0; d < v1.length; d++) {
                arr.push(v1[d] + ((v2[d] || v1[d]) - v1[d]) * t);
            }
            return arr;
        }

        return v1; // Fallback
    }

    // Refresco de UI Suave
    function forceUIRefresh() {
        var seq = app.project.activeSequence;
        if (seq) {
            var p = seq.getPlayerPosition();
            if (p && p.ticks) {
                var ticksString = p.ticks.toString();
                var nudgeAmount = 2540160000;
                try {
                    var tNum = Number(ticksString);
                    seq.setPlayerPosition((tNum + nudgeAmount).toString());
                    seq.setPlayerPosition(ticksString);
                } catch (e) { }
            }
        }
    }

    _GRAPHEDITORPR.applyInfluence = function (outVal, inVal, vOut, vIn, mode, filters) {
        return withUndoGroup('GraphEditorPR Apply', function () {
            var seq = app.project.activeSequence;
            if (!seq) return "Error";
            var selection = seq.getSelection();
            if (!selection || selection.length === 0) return "Selecciona clips";

            var seqPlayerTime = seq.getPlayerPosition().seconds;
            var oInfl = parseFloat(outVal) / 100;
            var iInfl = parseFloat(inVal) / 100;
            var filterArr = filters ? filters.split(',') : [];

            var batchMap = {};
            for (var i = 0; i < selection.length; i++) {
                var clip = selection[i];
                var clipLocalTime = (seqPlayerTime - clip.start.seconds) + clip.inPoint.seconds;
                if (clip.components) {
                    processComponents(clip.components, oInfl, iInfl, vOut, vIn, mode, filterArr, false, false, 0, clipLocalTime, batchMap, i);
                }
            }
            // Commit undo batch
            var batch = [];
            for (var k in batchMap) { if (batchMap.hasOwnProperty(k)) batch.push(batchMap[k]); }
            if (batch.length > 0) {
                _UNDO_STACK.push(batch);
                _REDO_STACK = []; // nueva acción invalida redo
            }
            forceUIRefresh();
            return "Aplicado";
        });
    };

    _GRAPHEDITORPR.undoLast = function () {
        return withUndoGroup('GraphEditorPR Undo', function () {
            try {
                if (!_UNDO_STACK || _UNDO_STACK.length === 0) return "Nada para deshacer";
                var batch = _UNDO_STACK.pop();
                var removed = 0;
                for (var i = 0; i < batch.length; i++) {
                    var item = batch[i];
                    if (!item || !item.prop || !item.points) continue;
                    for (var t = 0; t < item.points.length; t++) {
                        try { item.prop.removeKey(item.points[t].time); removed++; } catch (e) { }
                    }
                }
                _REDO_STACK.push(batch);
                forceUIRefresh();
                return "Deshecho";
            } catch (e2) {
                return "Error";
            }
        });
    };

    _GRAPHEDITORPR.redoLast = function () {
        return withUndoGroup('GraphEditorPR Redo', function () {
            try {
                if (!_REDO_STACK || _REDO_STACK.length === 0) return "Nada para rehacer";
                var batch = _REDO_STACK.pop();
                var added = 0;
                for (var i = 0; i < batch.length; i++) {
                    var item = batch[i];
                    if (!item || !item.prop || !item.points) continue;
                    for (var t = 0; t < item.points.length; t++) {
                        var p = item.points[t];
                        try {
                            item.prop.addKey(p.time);
                            item.prop.setValueAtKey(p.time, p.value, true);
                            added++;
                        } catch (e) { }
                    }
                }
                _UNDO_STACK.push(batch);
                forceUIRefresh();
                return "Rehecho";
            } catch (e2) {
                return "Error";
            }
        });
    };

    _GRAPHEDITORPR.cleanCurve = function (filters) {
        return withUndoGroup('GraphEditorPR Clean', function () {
            var seq = app.project.activeSequence;
            if (!seq) return "Error";
            var selection = seq.getSelection();
            if (!selection || selection.length === 0) return "Selecciona clips";
            var filterArr = filters ? filters.split(',') : [];
            var seqPlayerTime = seq.getPlayerPosition().seconds;

            for (var i = 0; i < selection.length; i++) {
                var clip = selection[i];
                var clipLocalTime = (seqPlayerTime - clip.start.seconds) + clip.inPoint.seconds;
                if (clip.components) {
                    processComponents(clip.components, 0, 0, 0, 0, '', filterArr, true, false, 0, clipLocalTime, null, i);
                }
            }
            forceUIRefresh();
            return "Reseteado";
        });
    };

    _GRAPHEDITORPR.setKeyframeType = function (type, filters) {
        return withUndoGroup('GraphEditorPR Keyframe Type', function () {
            var seq = app.project.activeSequence; if (!seq) return "Error";
            var selection = seq.getSelection(); if (!selection || selection.length === 0) return "Error";

            var interp = (type === 'bezier') ? 5 : (type === 'hold' ? 4 : 0);
            var filterArr = filters ? filters.split(',') : [];
            for (var i = 0; i < selection.length; i++) {
                if (selection[i].components) processComponents(selection[i].components, 0, 0, 0, 0, '', filterArr, false, true, interp, 0, null, i);
            }
            forceUIRefresh();
            return type.toUpperCase();
        });
    };

    function processComponents(components, oInfl, iInfl, vOut, vIn, mode, filters, isClean, isInterp, interpVal, playerTime, batchMap, clipIdx) {
        if (!components) return;
        for (var c = 0; c < components.numItems; c++) {
            var comp = components[c];
            if (comp.properties) {
                for (var p = 0; p < comp.properties.numItems; p++) {
                    recursiveApply(comp.properties[p], oInfl, iInfl, vOut, vIn, mode, filters, isClean, isInterp, interpVal, playerTime, batchMap, clipIdx, c);
                }
            }
        }
    }

    // Los filtros son claves "clipIdx~compIdx~propName"; la UI también manda variantes "clipIdx~*~propName"
    // y "*~compIdx~propName" para tolerar multi-selección. Si no hay filtros -> aplicar a todo.
    function _matchFilter(filters, clipIdx, compIdx, propName) {
        if (!filters || filters.length === 0) return true;
        var pn = (propName || '').toLowerCase();
        for (var f = 0; f < filters.length; f++) {
            var parts = (filters[f] || '').split('~');
            // Legacy: un solo token = nombre propiedad
            if (parts.length === 1) {
                if (pn === parts[0].toLowerCase()) return true;
                continue;
            }
            if (parts.length < 3) continue;
            var fClip = parts[0], fComp = parts[1], fName = (parts[2] || '').toLowerCase();
            if (fName !== pn) continue;
            var clipOk = (fClip === '*' || parseInt(fClip, 10) === clipIdx);
            var compOk = (fComp === '*' || parseInt(fComp, 10) === compIdx);
            if (clipOk && compOk) return true;
        }
        return false;
    }

    function recursiveApply(prop, oInfl, iInfl, vOut, vIn, mode, filters, isClean, isInterp, interpVal, playerTime, batchMap, clipIdx, compIdx) {
        if (!prop) return;

        // Recursión para grupos (Ej. Máscaras)
        try {
            if (prop.numItems > 0) {
                for (var j = 0; j < prop.numItems; j++) {
                    recursiveApply(prop[j], oInfl, iInfl, vOut, vIn, mode, filters, isClean, isInterp, interpVal, playerTime, batchMap, clipIdx, compIdx);
                }
            }
        } catch (e) { }

        if (prop.areKeyframesSupported && prop.areKeyframesSupported()) {
            var propName = (prop.displayName || prop.matchName || "");
            if (!_matchFilter(filters, clipIdx, compIdx, propName)) return;
            if (isClean) performSegmentClean(prop, playerTime);
            else if (isInterp) try { setPropInterpolation(prop, interpVal); } catch (e) { }
            else applyBakingLogic(prop, oInfl, iInfl, vOut, vIn, mode, playerTime, batchMap);
        }
    }

    _GRAPHEDITORPR.scanActiveProperties = function () {
        var seq = app.project.activeSequence; if (!seq) return "";
        var selection = seq.getSelection(); if (!selection || selection.length === 0) return "";
        var list = [];
        var seen = {};
        for (var i = 0; i < selection.length; i++) {
            var clip = selection[i];
            if (clip.components) {
                for (var c = 0; c < clip.components.numItems; c++) {
                    var comp = clip.components[c];
                    var compName = (comp && (comp.displayName || comp.matchName)) ? (comp.displayName || comp.matchName) : 'FX';
                    if (comp && comp.properties) {
                        for (var p = 0; p < comp.properties.numItems; p++) {
                            recursiveCheck(comp.properties[p], list, seen, i, c, compName);
                        }
                    }
                }
            }
        }
        // Formato: "clipIdx~compIdx~compName~propName", varias entradas separadas por ","
        var out = [];
        for (var k = 0; k < list.length; k++) {
            var it = list[k];
            out.push(it.clipIdx + '~' + it.compIdx + '~' + (it.compName || '') + '~' + it.propName);
        }
        return out.join(',');
    };

    function recursiveCheck(param, list, seen, clipIdx, compIdx, compName) {
        if (!param) return;
        try { if (param.numItems > 0) { for (var i = 0; i < param.numItems; i++) recursiveCheck(param[i], list, seen, clipIdx, compIdx, compName); } } catch (e) { }
        try {
            if (param.isTimeVarying && param.isTimeVarying()) {
                var keys = param.getKeys();
                if (keys && keys.length > 1) {
                    var pn = param.displayName || param.matchName || "Unknown";
                    var uniq = clipIdx + '~' + compIdx + '~' + pn;
                    if (!seen[uniq]) {
                        seen[uniq] = true;
                        list.push({ clipIdx: clipIdx, compIdx: compIdx, compName: compName, propName: pn });
                    }
                }
            }
        } catch (e) { }
    }

    function setPropInterpolation(prop, type) {
        var keys = prop.getKeys();
        if (!keys) return;
        for (var k = 0; k < keys.length; k++) {
            try {
                var t = (typeof keys[k] === 'object') ? keys[k].seconds : keys[k];
                prop.setInterpolationTypeAtKey(t, type, true);
            } catch (e) { }
        }
    }

    function getSegmentKeys(prop, playerTime) {
        var keys = prop.getKeys();
        if (!keys || keys.length < 2) return null;

        var L = -1, R = -1;
        // Buscamos el par de llaves que rodean el tiempo actual con un margen pequeño
        for (var i = 0; i < keys.length; i++) {
            var t = (typeof keys[i] === 'object') ? keys[i].seconds : keys[i];
            if (t <= playerTime + 0.01) { L = i; }
            if (t > playerTime - 0.01 && R === -1 && i > L) { R = i; break; }
        }

        // Si estamos al final o al principio extremo, cogemos el segmento adyacente
        if (L !== -1 && R === -1 && L > 0) { R = L; L = L - 1; }
        if (L === -1 && R !== -1 && R < keys.length - 1) { L = R; R = R + 1; }

        if (L === -1 || R === -1) return null;

        var finalL = L, finalR = R;

        // Cuando el playhead cae dentro de una ráfaga baked, L/R pueden ser 2 baked adyacentes.
        // Para no “encoger” el segmento, calculamos un umbral basado en el intervalo mínimo local.
        function tAt(idx) { return (typeof keys[idx] === 'object') ? keys[idx].seconds : keys[idx]; }

        var localMin = 999999;
        var from = Math.max(1, L - 4);
        var to = Math.min(keys.length - 1, R + 4);
        for (var ii = from; ii <= to; ii++) {
            var d = tAt(ii) - tAt(ii - 1);
            if (d > 0.000001 && d < localMin) localMin = d;
        }
        if (localMin === 999999) localMin = 0.15;

        // Umbral: todo lo que sea “cercano” al mínimo local se considera parte del baking cluster.
        var BAKE_THRESHOLD = Math.max(0.02, Math.min(0.60, localMin * 2.6));

        // Expandir hacia anchors reales: parar al encontrar un gap grande.
        while (finalL > 0) {
            var dl = tAt(finalL) - tAt(finalL - 1);
            if (dl > BAKE_THRESHOLD) break;
            finalL--;
        }
        while (finalR < keys.length - 1) {
            var dr = tAt(finalR + 1) - tAt(finalR);
            if (dr > BAKE_THRESHOLD) break;
            finalR++;
        }

        return {
            startTime: (typeof keys[finalL] === 'object') ? keys[finalL].seconds : keys[finalL],
            endTime: (typeof keys[finalR] === 'object') ? keys[finalR].seconds : keys[finalR]
        };
    }

    function removeKeysBetween(prop, startTime, endTime) {
        try {
            var keys = prop.getKeys();
            for (var k = keys.length - 1; k >= 0; k--) {
                var t = (typeof keys[k] === 'object') ? keys[k].seconds : keys[k];
                if (t > startTime + 0.002 && t < endTime - 0.002) {
                    try { prop.removeKey(t); } catch (e) { }
                }
            }
        } catch (e2) { }
    }

    function performSegmentClean(prop, playerTime) {
        var seg = getSegmentKeys(prop, playerTime);
        if (!seg) return;

        // Borramos SOLO lo que está estrictamente entre los anchors detectados
        removeKeysBetween(prop, seg.startTime, seg.endTime);

        try {
            // Truco de refresco visual (sin forzar lineal: queremos volver al estado original lo más posible)
            var v = prop.getValueAtKey(seg.startTime);
            if (typeof v === 'number') {
                prop.setValueAtKey(seg.startTime, v + 0.000001, true);
                prop.setValueAtKey(seg.startTime, v, true);
            }
        } catch (e) { }
    }

    function applyBakingLogic(prop, oInfl, iInfl, vOut, vIn, mode, playerTime, batchMap) {
        // Re-aplicar: detectar anchors reales del tramo (incluye ráfaga baked) y limpiar entre esos anchors.
        var seg = getSegmentKeys(prop, playerTime);
        if (!seg) return;

        var startTime = seg.startTime;
        var endTime = seg.endTime;
        var startVal = prop.getValueAtKey(startTime);
        var endVal = prop.getValueAtKey(endTime);

        removeKeysBetween(prop, startTime, endTime);

        var p1y = (mode === 'value') ? parseFloat(vOut) : 0;
        var p2y = (mode === 'value') ? parseFloat(vIn) + 1 : 1;

        var bakedTimes = [];
        for (var s = 1; s < BAKING_STEPS; s++) {
            var x = s / BAKING_STEPS;
            var t = solveBezierT(x, oInfl, 1 - iInfl);
            var ratio = getBezierPoint(t, 0, p1y, p2y, 1);
            var timePos = startTime + (x * (endTime - startTime));
            var newVal = interpolateValue(startVal, endVal, ratio);
            try {
                prop.addKey(timePos);
                prop.setValueAtKey(timePos, newVal, true);
                bakedTimes.push(timePos);
                if (batchMap) {
                    var uid = _getPropUid(prop);
                    if (uid !== null) {
                        if (!batchMap[uid]) batchMap[uid] = { prop: prop, points: [] };
                        batchMap[uid].points.push({ time: timePos, value: newVal });
                    }
                }
            } catch (e) { }
        }

        // Interp LINEAR dentro del segmento:
        //  - Anchor inicial: outgoing LINEAR (incoming NO se toca: pertenece al tramo anterior).
        //  - Anchor final: incoming LINEAR (outgoing NO se toca: pertenece al tramo siguiente).
        //  - Baked intermedios: LINEAR ambos lados.
        // Con 20 samples por tramo la forma queda suave, sin "kink" del primer keyframe.
        try { prop.setInterpolationTypeAtKey(startTime, 0, 2); } catch (e) { }
        try { prop.setInterpolationTypeAtKey(endTime, 0, 1); } catch (e) { }
        for (var bt = 0; bt < bakedTimes.length; bt++) {
            try { prop.setInterpolationTypeAtKey(bakedTimes[bt], 0, 1); } catch (e) { }
            try { prop.setInterpolationTypeAtKey(bakedTimes[bt], 0, 2); } catch (e) { }
        }
    }
})();
