/* --- GraphEditorPR main.js (Premiere Pro) --- */
(function () {
    'use strict';

    var csInterface = new CSInterface();

    // Referencias UI
    const mainLayout = document.getElementById('mainLayout');
    const primaryColumn = document.getElementById('primaryColumn');
    const resizeGutter = document.getElementById('resizeGutter');
    const sliderOut = document.getElementById('sliderOut');
    const sliderIn = document.getElementById('sliderIn');
    const outValDisplay = document.getElementById('outValDisplay');
    const inValDisplay = document.getElementById('inValDisplay');
    const applyBtn = document.getElementById('applyBtn');
    const btnModeVel = document.getElementById('btnModeVelocity');
    const btnModeVal = document.getElementById('btnModeValue');
    const undoBtn = document.getElementById('undoBtn');
    const redoBtn = document.getElementById('redoBtn');
    const filterRow = document.getElementById('filterRow');
    const reverseBtn = document.getElementById('reverseBtn');
    const lockBtnToolbar = document.getElementById('lockBtnToolbar');

    const presetsGrid = document.getElementById('presetsGrid');
    const presetsToggle = document.getElementById('presetsToggle');
    const presetsPanel = document.getElementById('presetsPanel');
    const presetFilterAll = document.getElementById('presetFilterAll');
    const presetFilterFav = document.getElementById('presetFilterFav');
    const presetFavToggleBtn = document.getElementById('presetFavToggleBtn');
    const addPresetBtn = document.getElementById('addPresetBtn');
    const removePresetBtn = document.getElementById('removePresetBtn');

    const presetNameModal = document.getElementById('presetNameModal');
    const presetNameInput = document.getElementById('presetNameInput');
    const presetNameCancel = document.getElementById('presetNameCancel');
    const presetNameOk = document.getElementById('presetNameOk');

    // Referencias SVG
    const baseLineL = document.getElementById('graphBaseLeft');
    const baseLineR = document.getElementById('graphBaseRight');
    const graphContainer = document.getElementById('graphContainer');
    const speedGraphSVG = document.getElementById('speedGraphSVG');
    const graphCurve = document.getElementById('graphCurve');
    const graphFill = document.getElementById('graphFill');
    const hLineL = document.getElementById('handleLineLeft');
    const hLineR = document.getElementById('handleLineRight');
    const pointL = document.getElementById('handlePointLeft');
    const pointR = document.getElementById('handlePointRight');
    const dragAreaL = document.getElementById('dragAreaLeft');
    const dragAreaR = document.getElementById('dragAreaRight');
    const dragGroupLeft = document.getElementById('dragGroupLeft');
    const dragGroupRight = document.getElementById('dragGroupRight');

    // Constantes Visuales
    const SVG_WIDTH = 300;
    const SVG_HEIGHT = 300;
    const HANDLE_PADDING = 20;

    // Estado
    let isLocked = false;
    let isDraggingLeft = false;
    let isDraggingRight = false;
    let handleLeftY = 0;
    // En modo VALUE el control derecho parte en 1 (para que la curva no salga “rara” al cambiar de modo)
    let handleRightY = 1;
    let graphMode = 'velocity';
    let currentViewScale = 1;
    let dragStartX = 0;
    let dragStartY = 0;
    let dragStartValX = 0;
    let dragStartValY = 0;
    let dragStartScale = 1;

    // --- Layout responsive (horizontal/vertical) ---
    let layoutMode = 'vertical';
    const LAYOUT_THRESHOLD = 520;
    let userSplitHeightPx = null;
    let userSplitWidthPx = null;

    // --- Estado Presets (solo Graph) ---
    let favoritesSet = new Set();
    let customPresets = [];
    let allPresets = [];
    /** Preset seleccionado en la grilla (para fav/−) */
    let selectedPresetId = null;
    let showingFavoritesOnly = false;

    // --- Presets por defecto (Graph) ---
    const DEFAULT_PRESETS = [
        { id: 'ease_in', family: 'graph', name: 'Ease In', o: 0, i: 70 },
        { id: 'ease_out', family: 'graph', name: 'Ease Out', o: 70, i: 0 },
        { id: 'ease_in_out', family: 'graph', name: 'Ease In Out', o: 70, i: 70 },
        { id: 'linear', family: 'graph', name: 'Linear', o: 0.1, i: 0.1 },
        { id: 'steep_in', family: 'graph', name: 'Steep In', o: 0, i: 100 },
        { id: 'steep_out', family: 'graph', name: 'Steep Out', o: 100, i: 0 },
        { id: 'expo_in', family: 'graph', name: 'Expo In', o: 0, i: 90 },
        { id: 'expo_out', family: 'graph', name: 'Expo Out', o: 90, i: 0 },
        { id: 'sharp_in', family: 'graph', name: 'Sharp In', o: 50, i: 100 },
        { id: 'sharp_out', family: 'graph', name: 'Sharp Out', o: 100, i: 50 }
    ];

    // --- 2. MOTOR GRÁFICO ---
    function cubicBezier(t, p0, p1, p2, p3) {
        const u = 1 - t; const tt = t * t; const uu = u * u; const uuu = uu * u; const ttt = tt * t;
        return (uuu * p0) + (3 * uu * t * p1) + (3 * u * tt * p2) + (ttt * p3);
    }
    function cubicBezierDerivative(t, p0, p1, p2, p3) {
        const u = 1 - t; return (3 * u * u * (p1 - p0)) + (6 * u * t * (p2 - p1)) + (3 * t * t * (p3 - p2));
    }

    function getStandardizedPath(o, i, vO, vI, mode) {
        let mcp1x = o / 100; let mcp2x = 1 - (i / 100);
        let mcp1y = (mode === 'velocity') ? 0 : vO; let mcp2y = (mode === 'velocity') ? 0 : vI;
        const steps = 25; let points = []; let minVal = 0, maxVal = 1;
        for (let s = 0; s <= steps; s++) {
            let t = s / steps;
            let bx = cubicBezier(t, 0, mcp1x, mcp2x, 1);
            let by = 0;
            if (mode === 'value') { by = cubicBezier(t, 0, mcp1y, mcp2y, 1); }
            else {
                let dx = cubicBezierDerivative(t, 0, mcp1x, mcp2x, 1); let dy = cubicBezierDerivative(t, 0, 0, 1, 1);
                if (dx > 0.0001) by = dy / dx; if (by > 25) by = 25;
            }
            if (by > maxVal) maxVal = by; if (by < minVal) minVal = by;
            points.push({ x: bx, y: by });
        }
        let rangeY = maxVal - minVal; if (rangeY < 0.001) rangeY = 1;
        const pad = 0.2;
        let visualMinY = minVal - (rangeY * pad);
        let visualMaxY = maxVal + (rangeY * pad);
        let visualRangeY = visualMaxY - visualMinY;
        const mapX = (x) => 10 + (x * 280);
        const mapY = (y) => 290 - ((y - visualMinY) / visualRangeY * 280);
        let d = "";
        points.forEach((p, idx) => { d += (idx === 0 ? "M" : "L") + " " + mapX(p.x).toFixed(1) + "," + mapY(p.y).toFixed(1); });
        return d;
    }

    function updateGraphVisuals() {
        let o = parseFloat(sliderOut.value);
        let i = parseFloat(sliderIn.value);
        outValDisplay.textContent = Math.round(o) + '%';
        inValDisplay.textContent = Math.round(i) + '%';

        let mcp1x = o / 100; let mcp2x = 1 - (i / 100);
        let mcp1y = (graphMode === 'velocity') ? 0 : handleLeftY;
        let mcp2y = (graphMode === 'velocity') ? 0 : handleRightY;

        const steps = 120; let rawPoints = []; let minVal = 0, maxVal = 1;
        if (graphMode === 'value') { minVal = Math.min(0, handleLeftY, handleRightY); maxVal = Math.max(1, handleLeftY, handleRightY); } else { maxVal = 2.0; }

        for (let s = 0; s <= steps; s++) {
            let t = s / steps;
            let bx = cubicBezier(t, 0, mcp1x, mcp2x, 1);
            let by = 0;
            if (graphMode === 'value') { by = cubicBezier(t, 0, mcp1y, mcp2y, 1); }
            else {
                let dx = cubicBezierDerivative(t, 0, mcp1x, mcp2x, 1); let dy = cubicBezierDerivative(t, 0, 0, 1, 1);
                if (dx > 0.0001) by = dy / dx; if (by > 100) by = 100;
            }
            if (by > maxVal) maxVal = by; if (by < minVal) minVal = by;

            if (rawPoints.length > 0) {
                let prev = rawPoints[rawPoints.length - 1];
                if (Math.abs(bx - prev.x) < 0.0001 && Math.abs(by - prev.y) < 0.0001) continue;
            }
            rawPoints.push({ x: bx, y: by });
        }

        let rangeY = maxVal - minVal; if (rangeY < 0.001) rangeY = 1;
        const paddingMultiplier = 0.2;
        let visualMinY = minVal - (rangeY * paddingMultiplier);
        let visualMaxY = maxVal + (rangeY * paddingMultiplier);
        let visualRangeY = visualMaxY - visualMinY;

        if (graphMode === 'value') currentViewScale = Math.max(1.0 + (paddingMultiplier * 2), visualRangeY); else currentViewScale = 1.0;

        let centerY = (visualMinY + visualMaxY) / 2;
        let viewMinY = centerY - (currentViewScale / 2); let viewMaxY = centerY + (currentViewScale / 2);
        let centerX = 0.5; let viewMinX = centerX - (currentViewScale / 2); let viewMaxX = centerX + (currentViewScale / 2);
        const usableSize = SVG_WIDTH - (HANDLE_PADDING * 2);

        const mapY = (val) => { let normalized = (graphMode === 'value') ? (val - viewMinY) / currentViewScale : (val - visualMinY) / visualRangeY; return SVG_HEIGHT - HANDLE_PADDING - (normalized * usableSize); };
        const mapX = (val) => { let normalized = (graphMode === 'value') ? (val - viewMinX) / currentViewScale : val; return HANDLE_PADDING + (normalized * usableSize); };

        let dCurve = "", dFill = ""; const floorY = mapY(0);
        for (let idx = 0; idx < rawPoints.length; idx++) {
            let p = rawPoints[idx]; let px = mapX(p.x); let py = mapY(p.y);
            let cmd = (idx === 0) ? "M" : "L"; dCurve += `${cmd} ${px},${py}`;
            if (idx === 0) dFill += `M ${px},${floorY} L ${px},${py}`; else dFill += ` L ${px},${py}`;
        }
        let endX = mapX(1); dFill += ` L ${endX},${floorY} Z`;
        graphCurve.setAttribute('d', dCurve); graphFill.setAttribute('d', dFill);

        // Grid
        let dGrid = ""; const FAR_PIXEL = 3000;
        if (graphMode === 'value') {
            const gridStep = 0.25;
            let startX = Math.floor((viewMinX - 2) / gridStep) * gridStep;
            let endX = Math.ceil((viewMaxX + 2) / gridStep) * gridStep;
            for (let gx = startX; gx <= endX; gx += gridStep) { let xPos = mapX(gx); dGrid += `M ${xPos},${-FAR_PIXEL} L ${xPos},${FAR_PIXEL} `; }
            let startY = Math.floor((viewMinY - 2) / gridStep) * gridStep;
            let endY = Math.ceil((viewMaxY + 2) / gridStep) * gridStep;
            for (let gy = startY; gy <= endY; gy += gridStep) { let yPos = mapY(gy); dGrid += `M ${-FAR_PIXEL},${yPos} L ${FAR_PIXEL},${yPos} `; }
        } else {
            // Velocity: usar malla completa (similar a Value) pero en el rango visual actual.
            const gridStep = 0.125;
            for (let gx = 0; gx <= 1.0001; gx += gridStep) {
                const xPos = mapX(gx);
                dGrid += `M ${xPos},${-FAR_PIXEL} L ${xPos},${FAR_PIXEL} `;
            }
            for (let gyN = 0; gyN <= 1.0001; gyN += gridStep) {
                const val = visualMinY + (gyN * visualRangeY);
                const yPos = mapY(val);
                dGrid += `M ${-FAR_PIXEL},${yPos} L ${FAR_PIXEL},${yPos} `;
            }
        }
        document.getElementById('gridPath').setAttribute('d', dGrid);

        // Handles
        let h1x, h2x, h1y, h2y;
        if (graphMode === 'velocity') {
            // --- POSICIONAR ELEMENTOS Y EJES (Mapping original PPro) ---
            h1x = HANDLE_PADDING + ((o / 100) * 0.5 * usableSize); h1y = mapY(0);
            h2x = (HANDLE_PADDING + usableSize) - ((i / 100) * 0.5 * usableSize); h2y = mapY(0);
        } else {
            h1x = mapX(mcp1x); h1y = mapY(mcp1y); h2x = mapX(mcp2x); h2y = mapY(mcp2y);
        }

        // Ocultar líneas base para no ensuciar el diseño
        baseLineL.style.display = 'none';
        baseLineR.style.display = 'none';

        hLineL.setAttribute('x1', mapX(0)); hLineL.setAttribute('y1', mapY(0)); hLineL.setAttribute('x2', h1x); hLineL.setAttribute('y2', h1y);
        let anchorRightY = (graphMode === 'velocity') ? 0 : 1; hLineR.setAttribute('x1', mapX(1)); hLineR.setAttribute('y1', mapY(anchorRightY)); hLineR.setAttribute('x2', h2x); hLineR.setAttribute('y2', h2y);
        pointL.setAttribute('cx', h1x); pointL.setAttribute('cy', h1y); pointR.setAttribute('cx', h2x); pointR.setAttribute('cy', h2y);
        dragAreaL.setAttribute('x', h1x - 20); dragAreaL.setAttribute('y', h1y - 20); dragAreaR.setAttribute('x', h2x - 20); dragAreaR.setAttribute('y', h2y - 20);
    }

    function setLayout(nextMode) {
        const mode = (nextMode === 'horizontal') ? 'horizontal' : 'vertical';
        if (layoutMode === mode) return;
        layoutMode = mode;
        mainLayout.classList.toggle('layout-horizontal', mode === 'horizontal');
        mainLayout.classList.toggle('layout-vertical', mode !== 'horizontal');

        // reset inline sizes when switching modes (we keep userSplit* to restore later)
        primaryColumn.style.height = '';
        primaryColumn.style.width = '';
        primaryColumn.style.flexBasis = '';
        mainLayout.classList.remove('has-fixed-split');
        resizeGutter.classList.remove('is-dragging');

        // restore last split for this mode if any
        if (mode === 'vertical' && userSplitHeightPx) {
            primaryColumn.style.height = userSplitHeightPx + 'px';
            primaryColumn.style.flexBasis = userSplitHeightPx + 'px';
            mainLayout.classList.add('has-fixed-split');
        }
        if (mode === 'horizontal' && userSplitWidthPx) {
            primaryColumn.style.width = userSplitWidthPx + 'px';
            primaryColumn.style.flexBasis = userSplitWidthPx + 'px';
            mainLayout.classList.add('has-fixed-split');
        }
        setTimeout(updateGraphVisuals, 30);
    }

    function syncLayoutFromWindow() {
        const next = (window.innerWidth >= LAYOUT_THRESHOLD) ? 'horizontal' : 'vertical';
        setLayout(next);
    }

    // --- 3. INTERACCIÓN ---
    function startDragLeft(e) { isDraggingLeft = true; isDraggingRight = false; document.body.style.cursor = 'move'; dragStartX = e.clientX; dragStartY = e.clientY; dragStartValX = parseFloat(sliderOut.value); dragStartValY = handleLeftY; dragStartScale = (graphMode === 'value') ? currentViewScale : 1; }
    function startDragRight(e) { isDraggingRight = true; isDraggingLeft = false; document.body.style.cursor = 'move'; dragStartX = e.clientX; dragStartY = e.clientY; dragStartValX = parseFloat(sliderIn.value); dragStartValY = handleRightY; dragStartScale = (graphMode === 'value') ? currentViewScale : 1; }
    function handleDrag(e) {
        if (!isDraggingLeft && !isDraggingRight) return;
        const rect = speedGraphSVG.getBoundingClientRect();
        const usableSize = rect.width - (HANDLE_PADDING * 2 * (rect.width / SVG_WIDTH));

        let pixelsFor100;
        if (graphMode === 'velocity') { pixelsFor100 = usableSize * 0.48; } else { pixelsFor100 = usableSize / dragStartScale; }

        const deltaX = (e.clientX - dragStartX) / pixelsFor100 * 100;
        let changeX = isDraggingRight ? -deltaX : deltaX;
        let newValX = Math.max(0.1, Math.min(100, dragStartValX + changeX));

        if (graphMode === 'value') {
            const deltaY = -(e.clientY - dragStartY) / usableSize * dragStartScale;
            if (isDraggingLeft) handleLeftY = dragStartValY + deltaY; else handleRightY = dragStartValY + deltaY;
        }

        const shouldLink = isLocked || e.shiftKey;
        if (isDraggingLeft) {
            sliderOut.value = newValX;
            sliderOut.dispatchEvent(new Event('input'));
            if (shouldLink) { sliderIn.value = newValX; sliderIn.dispatchEvent(new Event('input')); if (graphMode === 'value') handleRightY = handleLeftY; }
        } else {
            sliderIn.value = newValX;
            sliderIn.dispatchEvent(new Event('input'));
            if (shouldLink) { sliderOut.value = newValX; sliderOut.dispatchEvent(new Event('input')); if (graphMode === 'value') handleLeftY = handleRightY; }
        }
        updateGraphVisuals();
    }
    function stopDrag() { isDraggingLeft = false; isDraggingRight = false; document.body.style.cursor = 'default'; }

    dragGroupLeft.addEventListener('mousedown', startDragLeft);
    dragGroupRight.addEventListener('mousedown', startDragRight);
    window.addEventListener('mousemove', handleDrag);
    window.addEventListener('mouseup', stopDrag);

    // --- 4. PRESETS (UI tipo After) ---
    function loadPresets() {
        try {
            const sFav = localStorage.getItem('grapheditorprFavs_PPro');
            if (sFav) favoritesSet = new Set(JSON.parse(sFav));
            const sCust = localStorage.getItem('grapheditorprCustomPresets_PPro');
            if (sCust) customPresets = JSON.parse(sCust);
            const sOrder = localStorage.getItem('grapheditorprOrder_PPro');
            const order = sOrder ? JSON.parse(sOrder) : [];

            const baseList = DEFAULT_PRESETS.map(p => ({ ...p, isDefault: true }));
            const merged = baseList.concat(customPresets.map(p => ({ ...p, isDefault: false })));
            if (order.length > 0) {
                allPresets = order.map(id => merged.find(p => p.id === id)).filter(Boolean);
                merged.forEach(p => { if (!order.includes(p.id)) allPresets.push(p); });
            } else {
                allPresets = merged;
            }
        } catch (e) {
            allPresets = DEFAULT_PRESETS.map(p => ({ ...p, isDefault: true }));
        }
    }

    function savePresets() {
        try {
            localStorage.setItem('grapheditorprOrder_PPro', JSON.stringify(allPresets.map(p => p.id)));
            localStorage.setItem('grapheditorprFavs_PPro', JSON.stringify([...favoritesSet]));
            localStorage.setItem('grapheditorprCustomPresets_PPro', JSON.stringify(allPresets.filter(p => !p.isDefault)));
        } catch (e) { }
    }

    function setSelectedPreset(id) {
        selectedPresetId = id;
        presetsGrid.querySelectorAll('.preset-card').forEach(el => {
            el.classList.toggle('is-selected', el.id === id);
        });
        const isFav = id && favoritesSet.has(id);
        presetFavToggleBtn.classList.toggle('is-on', !!isFav);
    }

    function renderPresets() {
        presetsGrid.innerHTML = '';
        presetsGrid.classList.toggle('showing-favorites-only', showingFavoritesOnly);

        const list = showingFavoritesOnly ? allPresets.filter(p => favoritesSet.has(p.id)) : allPresets;
        list.forEach(p => {
            const div = document.createElement('div');
            div.className = 'preset-card' + (p.isDefault ? ' default-preset' : ' custom-preset');
            div.id = p.id;
            if (favoritesSet.has(p.id)) div.classList.add('is-favorite');
            if (selectedPresetId === p.id) div.classList.add('is-selected');

            const path = getStandardizedPath(parseFloat(p.o), parseFloat(p.i), p.vO || 0, p.vI || (graphMode === 'value' ? 1 : 0), graphMode);
            const name = p.customName || p.name;
            div.innerHTML = `<svg class="preset-icon" viewBox="0 0 300 300"><path d="${path}"/></svg>
                <div class="preset-name">${name}</div>`;

            div.addEventListener('click', () => {
                setSelectedPreset(p.id);
                sliderOut.value = p.o;
                sliderIn.value = p.i;
                if (graphMode === 'value') { handleLeftY = p.vO || 0; handleRightY = p.vI || 1; }
                updateGraphVisuals();
            });

            presetsGrid.appendChild(div);
        });
    }

    function openPresetModal() {
        presetNameInput.value = '';
        presetNameModal.classList.add('is-open');
        presetNameModal.setAttribute('aria-hidden', 'false');
        setTimeout(() => presetNameInput.focus(), 0);
    }

    function closePresetModal() {
        presetNameModal.classList.remove('is-open');
        presetNameModal.setAttribute('aria-hidden', 'true');
    }

    presetsToggle.addEventListener('click', () => {
        presetsPanel.classList.toggle('is-collapsed');
        mainLayout.classList.toggle('presets-collapsed', presetsPanel.classList.contains('is-collapsed'));
        setTimeout(updateGraphVisuals, 30);
    });

    presetFilterAll.addEventListener('click', () => {
        showingFavoritesOnly = false;
        presetFilterAll.classList.add('active');
        presetFilterFav.classList.remove('active');
        renderPresets();
    });

    presetFilterFav.addEventListener('click', () => {
        showingFavoritesOnly = true;
        presetFilterFav.classList.add('active');
        presetFilterAll.classList.remove('active');
        renderPresets();
    });

    presetFavToggleBtn.addEventListener('click', () => {
        if (!selectedPresetId) return;
        if (favoritesSet.has(selectedPresetId)) favoritesSet.delete(selectedPresetId);
        else favoritesSet.add(selectedPresetId);
        savePresets();
        renderPresets();
        setSelectedPreset(selectedPresetId);
    });

    addPresetBtn.addEventListener('click', openPresetModal);
    presetNameCancel.addEventListener('click', closePresetModal);
    presetNameModal.addEventListener('click', (e) => { if (e.target === presetNameModal) closePresetModal(); });
    presetNameOk.addEventListener('click', () => {
        const name = (presetNameInput.value || '').trim();
        if (!name) return;
        const p = {
            id: 'cust_' + Date.now(),
            family: 'graph',
            name: name,
            o: parseFloat(sliderOut.value),
            i: parseFloat(sliderIn.value),
            vO: handleLeftY,
            vI: handleRightY,
            isDefault: false
        };
        allPresets.push(p);
        savePresets();
        closePresetModal();
        renderPresets();
        setSelectedPreset(p.id);
    });

    removePresetBtn.addEventListener('click', () => {
        if (!selectedPresetId) return;
        const p = allPresets.find(x => x.id === selectedPresetId);
        if (!p || p.isDefault) return;
        allPresets = allPresets.filter(x => x.id !== selectedPresetId);
        favoritesSet.delete(selectedPresetId);
        selectedPresetId = null;
        savePresets();
        renderPresets();
        setSelectedPreset(null);
    });

    document.querySelectorAll('.preset-trigger').forEach(btn => {
        btn.addEventListener('click', () => {
            const o = parseFloat(btn.dataset.out || '50');
            const i = parseFloat(btn.dataset.in || '50');
            sliderOut.value = o;
            sliderIn.value = i;
            updateGraphVisuals();
        });
    });

    // Reverse
    reverseBtn.addEventListener('click', () => {
        const tmp = sliderOut.value;
        sliderOut.value = sliderIn.value;
        sliderIn.value = tmp;
        if (graphMode === 'value') {
            const tY = handleLeftY;
            handleLeftY = handleRightY;
            handleRightY = tY;
        }
        updateGraphVisuals();
    });

    // Lock (toolbar)
    function setLockState(next) {
        isLocked = !!next;
        lockBtnToolbar.classList.toggle('is-active', isLocked);
        lockBtnToolbar.setAttribute('aria-pressed', isLocked ? 'true' : 'false');
        lockBtnToolbar.title = isLocked ? 'Vincular (Activo)' : 'Vincular';
        if (isLocked) {
            sliderIn.value = sliderOut.value;
            if (graphMode === 'value') handleRightY = handleLeftY;
        }
        updateGraphVisuals();
    }
    lockBtnToolbar.addEventListener('click', () => setLockState(!isLocked));

    // Resize gutter (vertical/horizontal)
    let isDraggingGutter = false;
    resizeGutter.addEventListener('mousedown', () => {
        isDraggingGutter = true;
        resizeGutter.classList.add('is-dragging');
        mainLayout.classList.add('has-fixed-split');
    });
    window.addEventListener('mousemove', (e) => {
        if (!isDraggingGutter) return;
        if (layoutMode === 'horizontal') {
            const newW = e.clientX;
            if (newW > 220 && newW < window.innerWidth - 180) {
                userSplitWidthPx = newW;
                primaryColumn.style.width = newW + 'px';
                primaryColumn.style.flexBasis = newW + 'px';
                updateGraphVisuals();
            }
        } else {
            const newH = e.clientY;
            if (newH > 180 && newH < window.innerHeight - 120) {
                userSplitHeightPx = newH;
                primaryColumn.style.height = newH + 'px';
                primaryColumn.style.flexBasis = newH + 'px';
                updateGraphVisuals();
            }
        }
    });
    window.addEventListener('mouseup', () => { isDraggingGutter = false; resizeGutter.classList.remove('is-dragging'); });

    // --- 5. PREMIERE SCANNING & FILTERS ---
    function getActiveFilters() {
        const activeFilters = [];
        document.querySelectorAll('.filter-pill.active').forEach(p => { activeFilters.push(p.dataset.filter); });
        return activeFilters.join(',');
    }

    let lastResultStr = "";
    function scanProps() {
        csInterface.evalScript('_GRAPHEDITORPR.scanActiveProperties()', function (result) {
            if (result === lastResultStr) return;
            lastResultStr = result;
            const filterRow = document.getElementById('filterRow');
            const previousState = {};
            filterRow.querySelectorAll('.filter-pill').forEach(btn => { previousState[btn.dataset.filter] = btn.classList.contains('active'); });

            const foundFilters = result ? result.split(',') : [];
            filterRow.innerHTML = '';
            foundFilters.forEach(propName => {
                if (!propName) return;
                const btn = document.createElement('button');
                btn.className = 'filter-pill is-available'; btn.dataset.filter = propName; btn.innerText = propName;
                if (previousState.hasOwnProperty(propName)) { if (previousState[propName]) btn.classList.add('active'); } else { btn.classList.add('active'); }
                btn.addEventListener('click', function () { this.classList.toggle('active'); });
                filterRow.appendChild(btn);
            });

            const hasAny = filterRow.querySelectorAll('.filter-pill').length > 0;
            filterRow.classList.toggle('is-empty', !hasAny);
        });
    }
    window.addEventListener('focus', scanProps);
    setInterval(scanProps, 1500);

    // --- 6. APPLICATION LOGIC (PPRO) ---
    function applyToPPro() {
        applyBtn.innerText = "APLICANDO...";
        const vOut = (graphMode === 'value') ? handleLeftY : 0;
        const vIn = (graphMode === 'value') ? (handleRightY - 1) : 0;
        const filterStr = getActiveFilters();
        csInterface.evalScript(`_GRAPHEDITORPR.applyInfluence(${sliderOut.value}, ${sliderIn.value}, ${vOut}, ${vIn}, '${graphMode}', '${filterStr}')`, function (result) {
            applyBtn.innerText = result || "APLICADO";
            if ((result || '').toLowerCase().indexOf('aplic') >= 0) {
                undoBtn.classList.remove('is-hidden');
                redoBtn.classList.add('is-hidden');
            }
            setTimeout(() => applyBtn.innerText = "APLICAR", 2000);
        });
    }

    function undoInPanel() {
        const svg = undoBtn.querySelector('svg');
        if (svg) svg.style.display = 'none';
        undoBtn.textContent = '⏳';
        csInterface.evalScript('_GRAPHEDITORPR.undoLast()', function (result) {
            undoBtn.textContent = '';
            if (svg) { undoBtn.appendChild(svg); svg.style.display = 'block'; }
            if ((result || '').toLowerCase().indexOf('nada') >= 0) {
                undoBtn.classList.add('is-hidden');
            } else {
                redoBtn.classList.remove('is-hidden');
            }
            applyBtn.innerText = result || "OK";
            setTimeout(() => applyBtn.innerText = "APLICAR", 1200);
        });
    }

    function redoInPanel() {
        const svg = redoBtn.querySelector('svg');
        if (svg) svg.style.display = 'none';
        redoBtn.textContent = '⏳';
        csInterface.evalScript('_GRAPHEDITORPR.redoLast()', function (result) {
            redoBtn.textContent = '';
            if (svg) { redoBtn.appendChild(svg); svg.style.display = 'block'; }
            if ((result || '').toLowerCase().indexOf('nada') >= 0) {
                redoBtn.classList.add('is-hidden');
            } else {
                undoBtn.classList.remove('is-hidden');
            }
            applyBtn.innerText = result || "OK";
            setTimeout(() => applyBtn.innerText = "APLICAR", 1200);
        });
    }

    function setType(type) {
        const filters = getActiveFilters();
        csInterface.evalScript(`_GRAPHEDITORPR.setKeyframeType('${type}', '${filters}')`, function (result) {
            applyBtn.innerText = result || "OK";
            setTimeout(() => applyBtn.innerText = "APLICAR", 1500);
        });
    }

    // Listeners final
    undoBtn.addEventListener('click', undoInPanel);
    redoBtn.addEventListener('click', redoInPanel);
    applyBtn.addEventListener('click', applyToPPro);
    btnModeVel.addEventListener('click', () => {
        graphMode = 'velocity';
        btnModeVel.classList.add('active');
        btnModeVal.classList.remove('active');
        updateGraphVisuals();
    });
    btnModeVal.addEventListener('click', () => {
        graphMode = 'value';
        btnModeVal.classList.add('active');
        btnModeVel.classList.remove('active');
        // Si venimos de velocity y todavía no hubo edición en VALUE, setear defaults estables
        if (handleLeftY === 0 && handleRightY === 0) handleRightY = 1;
        updateGraphVisuals();
    });

    document.querySelectorAll('.kf-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            if (this.dataset.type) { setType(this.dataset.type); }
        });
    });

    sliderOut.addEventListener('input', () => { if (isLocked) sliderIn.value = sliderOut.value; updateGraphVisuals(); });
    sliderIn.addEventListener('input', () => { if (isLocked) sliderOut.value = sliderIn.value; updateGraphVisuals(); });

    // Asegurar foco para atajos (CEP a veces no dispara keydown si el panel no está enfocado)
    document.addEventListener('mousedown', () => {
        try { document.body.focus(); } catch (e) { }
    }, true);

    // Atajo dentro del panel: Ctrl+Z / Cmd+Z → deshacer último aplicado del panel
    document.addEventListener('keydown', (e) => {
        const isMac = /Mac/i.test(navigator.platform);
        const isUndo = (isMac && e.metaKey && (e.key === 'z' || e.key === 'Z')) || (!isMac && e.ctrlKey && (e.key === 'z' || e.key === 'Z'));
        if (!isUndo) return;
        if (e.shiftKey || e.altKey) return; // no interceptar redo/variantes
        e.preventDefault();
        csInterface.evalScript('_GRAPHEDITORPR.undoLast()', function (result) {
            applyBtn.innerText = result || "OK";
            setTimeout(() => applyBtn.innerText = "APLICAR", 1200);
        });
    }, true);

    loadPresets();
    renderPresets();
    updateGraphVisuals();
    scanProps();
    syncLayoutFromWindow();
    window.addEventListener('resize', syncLayoutFromWindow);

})();